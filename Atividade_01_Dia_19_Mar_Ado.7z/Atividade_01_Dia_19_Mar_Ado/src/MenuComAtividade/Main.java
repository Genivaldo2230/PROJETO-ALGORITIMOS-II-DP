package MenuComAtividade;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner ( System.in );
        int option;
        int[] vetor;
        vetor = new int[0];
        do {
            System.out.println ( "Escolha uma opção:" );
            System.out.println ( "==========================================================================" );
            System.out.println ( "1. Inicializar o vetor com números aleatórios" );
            System.out.println ( "==========================================================================" );
            System.out.println ( "2. Imprimir o vetor" );
            System.out.println ( "==========================================================================" );
            System.out.println ( "3. Verificar se um determinado número está contido no vetor" );
            System.out.println ( "==========================================================================" );
            System.out.println ( "4. Buscar o maior número armazenado no vetor" );
            System.out.println ( "==========================================================================" );
            System.out.println ( "5. Calcular a média dos números pares armazenados no vetor" );
            System.out.println ( "==========================================================================" );
            System.out.println ( "6. Calcular Percentual Numeros Impares Armaz Vetor" );
            System.out.println ( "==========================================================================" );
            System.out.println ( "7. Calcular Media Centralizada Vetor" );
            System.out.println ( "==========================================================================" );
            System.out.println ( "8. Somados Valores Informado" );
            System.out.println ( "==========================================================================" );

            System.out.println ( "0. Sair do programa" );
            option = sc.nextInt ();
            var i = 1;
            int indice = 0;
            switch (option) {
                case 1:
                    Random rd = new Random (); // Cria um objeto da classe Random
                    System.out.println ( "Digite entrada de Vetor Qtd ? :" );
                    int N = 0;// Define o tamanho do vetor
                    N = sc.nextInt (); //criação da quantida de vetor pelo ususario
                    vetor = new int[N];
                    int M = 100; // Define o valor máximo dos números
                    for (i = 0; i < N; i++) {
                        vetor[i] = rd.nextInt ( M ) + i; // Atribui um número aleatório entre 1 e M à posição i do vetor
                        System.out.println ( "Imprime o valor da posição i do vetor : " + vetor[i] + "\n " ); // Imprime o valor da posição i do vetor
                    }
                    break;
                case 2:
                    rd = new Random ();
                    System.out.println ( "Digite entrada de Vetor Qtd ? :" );
                    N = sc.nextInt (); //criação da quantida de vetor pelo ususario
                    vetor = new int[N];
                    M = 50;
                    for (i = 0; i < N; i++) {
                        vetor[i] = rd.nextInt ( M ) + i; // Atribui um número aleatório entre 1 e M à posição i do vetor
                        System.out.println ( "Imprime o valor da posição i do vetor [ " + vetor[i] + " ]" + "\n2Imprime o valor do vetor : " + M ); // Imprime o valor da posição i do vetor
                    }
                    break;
                case 3:
                    sc = new Scanner ( System.in );

                    int[] numeros = {10, 20, 30, 40};

                    System.out.println ( "Digite um numero: " );

                    int numero = sc.nextInt ();

                    indice = -1;

                    for (i = 0; i < numeros.length; i++) {

                        if (numeros[i] == numero) {

                            indice = i;

                            break;
                        }
                    }
                    if (indice != -1) {
                        System.out.println ( "O número está contido no vetor na posição " + indice );
                    } else {
                        System.out.println ( "O número não está contido no vetor." );
                    }
                case 4:
                    numeros = new int[50];
                    Random rand = new Random ();
                    numero = rand.nextInt ( 100 );
                    System.out.println ( "O número gerado foi: " + numero );
                    indice = -1;
                    for (i = 0; i < numeros.length; i++) {
                        if (numeros[i] == numero) {
                            indice = i;
                            break;
                        }
                    }
                    if (indice != -1) {
                        System.out.println ( "\nO número está contido no vetor na posição " + indice );
                        System.out.println ( "==========================================================================" );
                    } else {
                        System.out.println ( "\nO número não está contido no vetor." );
                        System.out.println ( "==========================================================================" );
                    }
                    break;

                case 8:
                    vetor = new int[]{1, 2, 3};
                    int sum = 0;
                    for (i = 0; i < vetor.length; i++) {
                        sum += vetor[i];
                    }
                    int matriz = sum / vetor.length;
                    System.out.println ( "Matriz Tem : " + matriz );
                    break;
                case 7:
                    double mediaCentralizada = mediaCentralizada ( vetor ); // chama a função e armazena o resultado em uma variável
                    System.out.println ( "A média centralizada é: " + mediaCentralizada ); // imprime a média centralizada na tela
                    break; // sai do switch case


                //case 0:
                // sair do programa
                // break;
                // default:
                //System.out.println ( "Opção inválida." );
            }

        } while (option != 0) ;
    }


    private static double mediaCentralizada(int[] vetor) {
        return 0;
    }
}
